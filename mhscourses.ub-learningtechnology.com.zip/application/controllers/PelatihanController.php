<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class PelatihanController extends CI_Controller {
	function __construct(){
		parent::__construct();
		$this->load->model('ClientModel');
		$this->api = 'https://api.mhscourses.ub-learningtechnology.com/api';
	}

	//---------------- FUNGSI UNTUK WEB ---------------------

    public function index() {
		
    }

    public function halamanMasterPelatihan(){
		$data = array(
			'title' => "Master Data Pelatihan"
		);
		
		$this->load->view('admin/master-pelatihan', $data);
    }
    
    public function getDatatableMasterPelatihan(){
		$url = $this->api.'/master/list-pelatihan';
		$request = $this->ClientModel->requestDataGet($url);
		echo json_encode($request);
    }
    
    public function tambahMasterPelatihan(){
		$url = $this->api.'/master/input-pelatihan';
		$data = array(
			'nama' => $this->input->post('nama'),
			'deskripsi' => $this->input->post('deskripsi')
		);
		$request = $this->ClientModel->requestDataPost($url,$data);
		echo json_encode($request);
    }
    
    public function hapusMasterPelatihan(){
		$url = $this->api.'/master/hapus-pelatihan';
		$data = array(
			'id' => $this->input->post('id')
		);
		$request = $this->ClientModel->requestDataPost($url, $data);
		echo json_encode($request);
    }
    
    public function detailMasterPelatihan(){
		$url = $this->api.'/master/detail-pelatihan';
		$data = array(
			'id' => $this->input->post('id')
		);
		$request = $this->ClientModel->requestDataPost($url, $data);
		echo json_encode($request);
    }
    
    public function editMasterPelatihan(){
		$url = $this->api.'/master/edit-pelatihan';
		$data = array(
			'id' => $this->input->post('id'),
			'nama' => $this->input->post('nama'),
			'deskripsi' => $this->input->post('deskripsi')
		);
		$request = $this->ClientModel->requestDataPost($url, $data);
		echo json_encode($request);
	}
}