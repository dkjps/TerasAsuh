<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
      <footer class="main-footer">
        <div class="footer-left">
          Copyright &copy; 2020 <div class="bullet"></div> Developed By <a href="#">UB Learning Technology Laboratory</a>
        </div>
        <div class="footer-right">
        </div>
      </footer>
    </div>
  </div>

<?php $this->load->view('admin/js'); ?>