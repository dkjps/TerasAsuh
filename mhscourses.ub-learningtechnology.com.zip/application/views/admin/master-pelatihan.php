<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$this->load->view('admin/header');
?>
<!-- Main Content -->
<div class="main-content" id="halaman-pasien">
    <section class="section">
        <div class="section-header">
            <h1>Master Data Pelatihan</h1>
        </div>
        <div class="section-body">
            <div class="row">
              <div class="col-12">
                <div class="card">
                  <div class="card-header">
                    <h4>Tabel Data Pelatihan</h4>
                    <div class="card-header-action">
                        <a href="#" class="btn btn-md btn-primary" data-toggle="modal" data-target="#modal-pelatihan-tambah">
                            <i class="fas fa-plus" style="padding-right:3px"></i>
                            <span style="font-size:10pt;">
                                Tambah Pelatihan
                            </span>
                        </a>
                    </div>
                  </div>
                  <div class="card-body">
                    <div class="table-responsive">
                      <table class="table table-striped" id="table-master-pelatihan">
                        <thead>
                          <tr>
                            <th style="width:15%;" class="text-center">No</th>
                            <th style="width:30%;" class="text-center">Nama Pelatihan</th>
                            <th style="width:30%;" class="text-center">Tipe Pelatihan</th>
                            <th style="width:25%;" class="text-center">Aksi</th>
                          </tr>
                        </thead>
                      </table>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
    </section>
</div>
<?php $this->load->view('admin/modal-master-pelatihan-tambah');?>
<?php $this->load->view('admin/modal-master-pelatihan-edit');?>
<?php $this->load->view('admin/footer'); ?>